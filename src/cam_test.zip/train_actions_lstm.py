import os, glob, numpy as np, torch, torch.nn as nn, torch.optim as optim
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from torch.utils.data import Dataset, DataLoader
from tqdm import tqdm
import joblib

DATA_DIR = "data/actions"
SEQ_LEN = 30
BATCH = 64
EPOCHS = 20
LR = 1e-3
HIDDEN = 128
LAYERS = 2
SEED = 42
torch.manual_seed(SEED)
np.random.seed(SEED)

# --- load data ---
paths, labels = [], []
for cls in sorted(os.listdir(DATA_DIR)):
    cdir = os.path.join(DATA_DIR, cls)
    if not os.path.isdir(cdir): continue
    for p in glob.glob(os.path.join(cdir, "*.npy")):
        paths.append(p); labels.append(cls)

le = LabelEncoder()
y = le.fit_transform(labels)
joblib.dump(le, "data/models/action_label_encoder.pkl")

# inspect one file for dims
sample = np.load(paths[0])        # (T, D)
T, D = sample.shape
print(f"Found {len(paths)} sequences | T={T}, D={D} | classes={list(le.classes_)}")

X_train, X_val, y_train, y_val = train_test_split(paths, y, test_size=0.2, stratify=y, random_state=SEED)

class SeqDs(Dataset):
    def __init__(self, paths, y): self.paths, self.y = paths, y
    def __len__(self): return len(self.paths)
    def __getitem__(self, i):
        arr = np.load(self.paths[i])       # (T,D)
        if arr.shape[0] != SEQ_LEN:        # pad/crop if needed
            if arr.shape[0] > SEQ_LEN: arr = arr[:SEQ_LEN]
            else:
                pad = np.zeros((SEQ_LEN-arr.shape[0], arr.shape[1]), dtype=arr.dtype)
                arr = np.vstack([arr, pad])
        x = torch.tensor(arr, dtype=torch.float32) # (T,D)
        return x, torch.tensor(self.y[i], dtype=torch.long)

train_dl = DataLoader(SeqDs(X_train, y_train), batch_size=BATCH, shuffle=True)
val_dl   = DataLoader(SeqDs(X_val,   y_val),   batch_size=BATCH)

# --- model ---
class BiLSTM(nn.Module):
    def __init__(self, input_dim, hidden, layers, num_cls):
        super().__init__()
        self.lstm = nn.LSTM(input_dim, hidden, num_layers=layers,
                            batch_first=True, bidirectional=True, dropout=0.2)
        self.head = nn.Sequential(
            nn.LayerNorm(hidden*2),
            nn.Dropout(0.3),
            nn.Linear(hidden*2, hidden),
            nn.ReLU(inplace=True),
            nn.Dropout(0.2),
            nn.Linear(hidden, num_cls)
        )
    def forward(self, x):                      # (B,T,D)
        out, _ = self.lstm(x)
        feat = out.mean(dim=1)                 # global mean pool over time
        return self.head(feat)

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = BiLSTM(D, HIDDEN, LAYERS, num_cls=len(le.classes_)).to(device)
crit = nn.CrossEntropyLoss()
opt  = optim.AdamW(model.parameters(), lr=LR)
best = 0.0

for epoch in range(1, EPOCHS+1):
    model.train(); tloss=0.0
    for xb,yb in tqdm(train_dl, desc=f"Epoch {epoch:02d}"):
        xb, yb = xb.to(device), yb.to(device)
        opt.zero_grad()
        pred = model(xb)
        loss = crit(pred, yb)
        loss.backward()
        opt.step()
        tloss += loss.item()*xb.size(0)

    # val
    model.eval(); correct=0; total=0
    with torch.no_grad():
        for xb,yb in val_dl:
            xb,yb = xb.to(device), yb.to(device)
            pred = model(xb).argmax(1)
            correct += (pred==yb).sum().item()
            total += yb.numel()
    acc = correct/total
    print(f"Epoch {epoch:02d} | loss {tloss/len(train_dl.dataset):.4f} | val_acc {acc:.3f}")

    if acc > best:
        best = acc
        os.makedirs("data/models", exist_ok=True)
        torch.save(model.state_dict(), "data/models/action_bilstm.pt")
        print("  ✅ Saved best model")

print(f"✅ Done. Best val_acc: {best:.3f}")
